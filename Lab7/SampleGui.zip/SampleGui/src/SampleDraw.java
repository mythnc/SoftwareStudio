import processing.core.PApplet;


public class SampleDraw extends PApplet{

	public void setup(){
		size(790,600);
		background(0);
	}
	public void draw(){
		
	}
	
}




