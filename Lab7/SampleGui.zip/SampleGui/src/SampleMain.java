import java.awt.BorderLayout;

import javax.swing.JFrame;


public class SampleMain extends JFrame{
	public SampleMain(){
		super("Data Visualization");
		setLayout(new BorderLayout());
		
		SamplePanel dataInput = new SamplePanel();
		add(dataInput, BorderLayout.EAST);
		
		pack();
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String args[]) {
		new SampleMain();
	  }
}



